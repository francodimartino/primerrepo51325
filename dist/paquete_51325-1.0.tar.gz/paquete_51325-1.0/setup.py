from setuptools import setup

setup(
    name="paquete_51325",
    version="1.0",
    description="Paquete de la comision 51325",
    author="la comi 51325",

    packages=["paquete"],
)

def funcion1():
    print("funcion1 del modulo paquete")

def funcion2():
    print("funcion2 del modulo paquete")
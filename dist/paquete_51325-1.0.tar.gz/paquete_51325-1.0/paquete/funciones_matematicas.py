def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    return a / b

def potencia(a, b):
    return a ** b

pi=3.141692654

def es_par(numero):
    if numero % 2 == 0:
        return True
    else:
        return False
        
